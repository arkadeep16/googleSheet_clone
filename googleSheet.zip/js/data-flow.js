/**
const selectedCellElement = document.querySelector('.selected-cell');
const form = document.getElementById('form');

const state = {};
const defaultStyle = {
  fontFamily: 'monospace',
  fontSize: 14,
  bold: false,
  italic: false,
  underline: false,
  alignment: 'left',
  textColor: '#000',
  bgColor: '#ffffff',
};

form.addEventListener('change', function onchange(params) {
  const selectedValues = {
    fontFamily: form.fontFamily.value,
    fontSize: form.fontSize.value,
    bold: form.bold.checked,
    italic: form.italic.checked,
    underline: form.underline.checked,
    alignment: form.alignment.value,
    textColor: form.textColor.value,
    bgColor: form.bgColor.value,
  };
  console.log(selectedValues);

  const selectedCellElement = document.getElementById(selectedCell);
  // console.log(selectedCellElement);
  selectedCellElement.style.fontFamily = selectedValues.fontFamily;
  selectedCellElement.style.fontSize = `${selectedValues.fontSize}px`;
  selectedCellElement.style.fontWeight = selectedValues.bold
    ? 'bold'
    : 'lighter';
  selectedCellElement.style.fontStyle = selectedValues.italic
    ? 'italic'
    : 'normal';
  selectedCellElement.style.textDecoration = selectedValues.underline
    ? 'underline'
    : 'none';
  selectedCellElement.style.textAlign = selectedValues.alignment;
  selectedCellElement.style.color = selectedValues.textColor;
  selectedCellElement.style.backgroundColor = selectedValues.bgColor;
});

let selectedCell = null;

function onFocus(event) {
  if (selectedCell) {
    document.getElementById(selectedCell).classList.remove('active-cell'); //remove the class for the previously focused cell
  }

  selectedCell = event.target.id; // the cells id given to "selectedCell"
  selectedCellElement.innerText = selectedCell;
  document.getElementById(selectedCell).classList.add('active-cell'); // add the class for the newly focused cell
  if (!state[selectedCell]) {
    state[selectedCell] = defaultStyle; // if the cell is focused for the first time then make it default style otherwise apply current style
    state[selectedCell].classList = 'active-cell';
  }

  applyCurrentCellStyleToForm();
}

function applyCurrentCellStyleToForm() {
  //apply styles of the current selected cell to the form

  // form.bold.checked = state[selectedCell].bold;

  for (let key in state[selectedCell]) {
    form[key].type === 'checkbox'
      ? (form[key].checked = state[selectedCell][key])
      : (form[key].value = state[selectedCell][key]);
  }
}

 */

// ///////////////////////////////===========================//////////////////////////////////////
const selectedCellElement = document.querySelector('.selected-cell');
const form = document.getElementById('form');

const state = {};

const defaultStyles = {
  fontFamily: 'monospace',
  fontSize: '16px',
  bold: 'false',
  italic: 'false',
  Underline: 'false',
  align: 'left',
  textColor: '#000',
  bgColor: 'transparent',
};

form.addEventListener('change', () => {
  let selectedValues = {
    fontFamily: form.fontFamily.value,
    fontSize: 16,
    bold: form.bold.checked,
    italic: form.italic.checked,
    Underline: form.underline.checked,
    align: form.alignment.value,
    textColor: form.textColor.value,
    bgColor: form.bgColor.value,
  };
  //   console.log(selectedValues);

  //now apply the styles to the selected cell

  const selectedCellElement = document.getElementsByClassName('selected-cell');
  selectedCellElement.style.fontFamily = selectedValues.fontFamily;
  selectedCellElement.style.fontSize = `${selectedValues.fontSize}px`;
  selectedCellElement.style.textAlign = selectedValues.align;
  selectedCellElement.style.fontWeight = selectedValues.bold
    ? 'regular'
    : '500';
  selectedCellElement.style.fontStyle = selectedValues.italic
    ? 'italic'
    : 'normal';
  selectedCellElement.style.textDecoration = selectedValues.underline
    ? 'underline'
    : 'none';
  selectedCellElement.style.color = selectedValues.textColor;
  selectedCellElement.style.backgroundColor = selectedValues.bgColor;
});

const selectedCell = null;

const onCellFocus = (e) => {
  const selectedCell = e.target.id;
  selectedCellElement.innerText = selectedCell;
  //console.log(state);
  if (!state[selectedCell]) {
    //console.log(selectedCell);
    // when the cell is focused for the first time give it the default styles
    state[selectedCell] = defaultStyles;
  }
  applyCurrentCellStylesToForm();
};

function applyCurrentCellStylesToForm() {
  // apply styles of the current selected cell to the form

  //   form.bold.checked = state[selectedCell].bold;
  //   form.italic.checked = state[selectedCell].italic;
  //   form.underline.checked = state[selectedCell].underline;
  //   form.align.value = state[selectedCell].align;
  //   form.fontSize.value = state[selectedCell].fontSize;
  //   form.fontFamily.value = state[selectedCell].fontFamily;
  //   form.textColor.value = state[selectedCell].textColor;
  //   form.bgColor.value = state[selectedCell].bgColor;
  for (const key in state[selectedCell]) {
    console.log(key);
    form.key.type === 'checkbox'
      ? (form[key].checked = state[selectedCell][key])
      : (form[key].value = state[selectedCell][key]);
  }
}
